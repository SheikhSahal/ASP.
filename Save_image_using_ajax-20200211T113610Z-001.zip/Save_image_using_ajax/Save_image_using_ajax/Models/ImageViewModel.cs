﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Save_image_using_ajax.Models
{
    public class ImageViewModel
    {
        public int id { get; set; }
        public string image_extension { get; set; }
        public string image_path { get; set; }

        public byte[] imagebyte { get; set; }
        public HttpPostedFileWrapper ImageFile { get; set; }
    }
}