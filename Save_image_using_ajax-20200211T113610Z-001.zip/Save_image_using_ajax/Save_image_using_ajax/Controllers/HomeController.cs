﻿using Save_image_using_ajax.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;

namespace MVCTutorial.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }


        public JsonResult ImageUpload(ImageViewModel model)
        {

            MVCEntities db = new MVCEntities();
            int imageId = 0;

            var file = model.ImageFile;

            byte[] imagebyte = null;

            if (file != null)
            {

                file.SaveAs(Server.MapPath("/Content/Image/" + file.FileName));

                BinaryReader reader = new BinaryReader(file.InputStream);

                imagebyte = reader.ReadBytes(file.ContentLength);

                Image img = new Image();

                img.image_extension = file.FileName;
                img.imagebyte = imagebyte;
                img.image_path = "/Content/Image/" + file.FileName;
                
                db.Images.Add(img);
                db.SaveChanges();

                imageId = img.id;

            }

            return Json(imageId, JsonRequestBehavior.AllowGet);

        }

        public ActionResult ImageRetrieve(int imgID)
        {
            MVCEntities db = new MVCEntities();

            var img = db.Images.SingleOrDefault(x => x.id == imgID);

            return File(img.imagebyte, "image/jpg");


        }
    }
}